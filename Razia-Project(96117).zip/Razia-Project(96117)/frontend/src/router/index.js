import Vue from "vue";
import VueRouter from "vue-router"
import Home from "../views/Home.vue"
import Users from "../views/Users.vue"
import EditUser from "../views/EditUser";
import Signup from "../views/Signup";
import Login from "../views/Login";


Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home
  },
  {
    path: "/user/add",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/AddUser.vue")
  },

  {
    path: "/user/all",
    name: "Users",
    component: Users,
    meta: {authentication: true}
  },

  {
    path: "/user/:id/edit",
    name: "EditUser",
    component: EditUser
  },
  {
    path: "/user/register",
    name: "Signup",
    component: Signup
  },
  {
    path: "/login",
    name: "Login",
    component: Login
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});


router.beforeEach((to, from, next) => {
  const loggedIn = localStorage.getItem("adminUser");
  if (to.matched.some(item => item.meta.authentication) && !loggedIn) {
    next("/");
  } else {
    next();
  }


})

export default router;
