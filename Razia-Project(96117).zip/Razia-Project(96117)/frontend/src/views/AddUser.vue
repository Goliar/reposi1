<template>
  <div class="about">
    <v-row>
     
      <v-col cols="12" class="mx-auto dark--text">
         <h1>Add User</h1>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="name" label="first name" outlined></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="lname" label="last name" outlined></v-text-field>
      </v-col>
    </v-row>

     <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-select
            :items="items"
            label="type "
            outlined

          >

          </v-select>
        </v-col>
      </v-row>

      <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-text-field v-model="phNumber" label="phNumber" outlined></v-text-field>
        </v-col>
      </v-row>

      <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-btn v-if="userId" color="info" @click="updateUser">Update</v-btn>

          <v-btn color="info" @click="saveUser">Save</v-btn>
        </v-col>
      </v-row>
  </div>
</template>

<script>
import UserService from "../api/UserService"
export default {
   props: ["userId"],
  data(){
    return {
      name:null,
      lname:null,
      phNumber:null,
      items:["temporary","permanently"],
      required: value => !!value || "This field is required"

    };
  },

  methods: {
   async saveUser() {
    //  if(this.$refs.form.validate()){
      const user = {
          name: this.name,
          lname : this.lname,
          phNumber : this.phNumber,
          items: this.items
        };

          
      const saveUser = await UserService.addUser(user);
        console.log(saveUser);
        this.resetForm();

        this.$router.push("/user/all");
      // }else{
      //   console.log("Form is not valid");
      // }
   


  },

  resetForm(){
  // this.$refs.form.reset();
  this.name =null
  this.lname =null
  this.phNumber =null
  this.type =null

}
}

}
</script>
