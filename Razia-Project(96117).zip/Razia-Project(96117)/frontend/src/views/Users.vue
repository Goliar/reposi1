<template>
  <div>
    <v-simple-table>
       <template v-slot:default>
         <thead>
           <tr>
             <th class= "text-left">First Name</th>
              <th class= "text-left">Last Name</th>
              <th class= "text-left">type</th>
              <th class= "text-left">phNumber</th>
               <th class= "text-left">Action</th>
           </tr>
         </thead>
         <tbody>
          <tr v-for= "user in users" :key= "user._id">
            <td>{{user.name}}</td>
            <td>{{user.lname}}</td>
             <td>{{user.type}}</td>
            <td>{{user.phNumber}}</td>

            <td>
              <v-btn :to= "`/user/${user._id}/edit`" small color= "warning" class= "mr-2" >Edit</v-btn>
              <v-btn small color= "error" @click= "deleteUser(user._id)" >Delete</v-btn>

            </td>

          </tr>
         </tbody>
       </template>
    </v-simple-table>
  </div>
</template>

<script>
import UserService from '../api/UserService'
export default {
  data(){
    return{
      users:[]
     
    }
  },
   methods:{
 async deleteUser(userId) {
   const conf= confirm("Do you want to delete the user?");
   if(conf){
   const response= await UserService.deleteById(userId);
      console.log(response.data);
      this.users= this.users.filter(user =>{
        return user._id!== UserService;
        
})
   }
 }
  },
  async mounted() {

   const response= await UserService.getAllUsers();
      this.users= response.data;
  }

}
</script>

<style>
th,
td {
  border: 1px solid grey;
}
</style>