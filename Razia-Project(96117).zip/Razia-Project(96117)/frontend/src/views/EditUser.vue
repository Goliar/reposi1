<template>
 <div>
       <v-row>
      <v-col cols = "12" sm = "6" class = "mx-auto dark--text"> 
        <h1>Edit User</h1>
      </v-col>
    </v-row>
     <UserForm :userId = "userId"/>
     
 </div>
</template>

<script>
import UserForm from "../components/UserForm"
export default {
components:{
UserForm:UserForm
},
data() {
    return{
        userId:this.$route.params.id
    }
}
}
</script>

<style>

</style>