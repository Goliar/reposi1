<template>
  <div class="about">
    <v-row>
     
      <v-col cols="12" class="mx-auto dark--text">
         <h1>Add Users</h1>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="name" label="name" outlined></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="lname" label="lname" outlined></v-text-field>
      </v-col>
    </v-row>

     <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-select
            :items="items"
            label="Type "
            outlined

          >

          </v-select>
        </v-col>
      </v-row>

      <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-text-field v-model="phNumber" label="Phon Number" outlined></v-text-field>
        </v-col>
      </v-row>

       <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-text-field v-model="address" label="Address" outlined></v-text-field>
        </v-col>
      </v-row>

      <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-btn color="info" @click="saveUser">Save</v-btn>
        </v-col>
      </v-row>
  </div>
</template>

<script>
import UserService from "../api/UserService"
export default {
  data(){
    return {
      name:null,
      lname:null,
      type:null,
      phNumber:null,
      address:null,
      items:["Primary","temporary"]
    };
  },

  methods: {
   async saveUser() {
      const user = {
        name: this.name,
        lname : this.lname,
        type : this.type,
        phNumber: this.phNumber,
        address:this.address
      };

     const saveUser = await UserService.addUser(user)
      console.log(saveUser);

      this.resetForm();

      this.$router.push("/user.all");

  },

  resetForm(){
  this.name =null
  this.lname =null
  this.type =null
  this.phNumber =null
  this.address = null

}
}

}
</script>
