import axiosClient from "./axiosClient";

export default {
  register(adminUser) {
    return axiosClient.post("/register", adminUser);
  },

  login(adminUser) {
    return axiosClient.post("/authenticate", adminUser);
  },

  addAuthorizationHeader(token) {
    axiosClient.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  }
}
