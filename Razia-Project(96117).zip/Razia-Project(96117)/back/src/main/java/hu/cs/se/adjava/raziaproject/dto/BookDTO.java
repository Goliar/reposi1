package hu.cs.se.adjava.raziaproject.dto;

public class BookDTO {

    private Integer id;
    private String type;
    private String name;
    private Integer quantity;
 
    private Integer customer_Id;

    
    public Integer getId() {
        return id;
    }
    
    
    public Integer getCustomer_Id() {
        return customer_Id;
    }


    public void setCustomer_Id(Integer customer_Id) {
        this.customer_Id = customer_Id;
    }


    public void setId(Integer id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    
    
}
