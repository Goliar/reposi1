package hu.cs.se.adjava.raziaproject.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.cs.se.adjava.raziaproject.Repository.amantBookRepository;
import hu.cs.se.adjava.raziaproject.dto.AmanatDTO;
import hu.cs.se.adjava.raziaproject.model.Amanatbook;

@Service
public class amanatBookServiceImpl implements amanatBookService {

    @Autowired
    private  amantBookRepository amanatRepository;

    @Autowired
    private ModelMapper modelMapper;
    
    @Override
    public Amanatbook saveAmanatbook(Amanatbook amanatbook) {
        
        return amanatRepository.save(amanatbook);
    }
    @Override
    public List<Amanatbook> getAll() {

        return amanatRepository.findAll();
    }
    
    @Override
    public Amanatbook getAmanatById(Integer id) {
        
        return amanatRepository.getOne(id);
    }
    @Override
    public void deleteAmanatbookById(Integer id) {
        amanatRepository.deleteById(id);
    }
  

    @Override
    public List<AmanatDTO> convertToDTO(List<Amanatbook> amanats) {
        
        
        List<AmanatDTO> amanatDTOList = new ArrayList<>();
        for(Amanatbook amanatbook : amanats) {

            AmanatDTO userDTO = modelMapper.map(amanatbook, AmanatDTO.class);
            amanatDTOList.add(userDTO);

        }
        return amanatDTOList;
    }
    @Override
    public AmanatDTO convertToDTO(Amanatbook amanatbook) {
        AmanatDTO userDTO = modelMapper.map(amanatbook, AmanatDTO.class);

        return userDTO;
    }
   
   
}
