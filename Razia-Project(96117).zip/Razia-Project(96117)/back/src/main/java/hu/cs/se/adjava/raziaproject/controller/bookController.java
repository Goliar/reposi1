package hu.cs.se.adjava.raziaproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.se.adjava.raziaproject.dto.BookDTO;
// import hu.cs.se.adjava.raziaproject.model.User;
import hu.cs.se.adjava.raziaproject.model.books;
import hu.cs.se.adjava.raziaproject.service.UserService;
import hu.cs.se.adjava.raziaproject.service.bookService;

@RestController
public class bookController {
    @Autowired
    private bookService bookService;

    @Autowired
    private UserService userService;
    

    // @Autowired
    // private UserService userService;

    @GetMapping(path = "/books/all")
    public ResponseEntity<List<BookDTO>> getAllbooks(){

        List<books> books = bookService.getAll();

        List<BookDTO> bookDTOList = bookService.convertToDTO(books);

        return new ResponseEntity<>(bookDTOList, HttpStatus.OK);
      
    }
    @PostMapping(path = "/books/add")
    public ResponseEntity<BookDTO> addBooks(@RequestBody books book){

       
        // book.setCustomer(userService.getUserById(2));

        books savedBooks = bookService.saveBook(book);
        
        BookDTO bookDTO = bookService.convertToDTO(savedBooks);
        return new ResponseEntity<>(bookDTO, HttpStatus.CREATED);
    }

    @GetMapping(path ="/books/{id}")
    public ResponseEntity<books> getBook(@PathVariable("id") Integer id){

        books book = bookService.getBookById(id);

        return new ResponseEntity<>(book, HttpStatus.OK);
    } 

    @PutMapping("/books/update")
    public ResponseEntity<books> updateUser(@RequestBody books book){

        books Savedbook = bookService.addBook(book);
         return new ResponseEntity<>(Savedbook, HttpStatus.OK);

        }

        
    @DeleteMapping("/books/{id}/delete")
        public ResponseEntity<String> deleteBook(@PathVariable("id") Integer id){

            bookService.deleteBookById(id);

            return new ResponseEntity<>("book " + id  + "deleted", HttpStatus.OK);
            
        }

}
