package hu.cs.se.adjava.raziaproject.dto;

public class AmanatDTO {
    
    private Integer id;
    private String name;
    private String time;
    private Integer cost;

    private Integer give_Amanat_ToUser_Id;

    public Integer getId() {
        return id;
    }


    public Integer getGive_Amanat_ToUser_Id() {
        return give_Amanat_ToUser_Id;
    }


    public void setGive_Amanat_ToUser_Id(Integer give_Amanat_ToUser_Id) {
        this.give_Amanat_ToUser_Id = give_Amanat_ToUser_Id;
    }


    public void setId(Integer id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public Integer getCost() {
        return cost;
    }
    public void setCost(Integer cost) {
        this.cost = cost;
    }


    
}
