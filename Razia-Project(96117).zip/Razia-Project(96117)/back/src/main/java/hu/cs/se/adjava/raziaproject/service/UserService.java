package hu.cs.se.adjava.raziaproject.service;

import java.util.List;

import hu.cs.se.adjava.raziaproject.dto.UserDTO;
import hu.cs.se.adjava.raziaproject.model.User;
/**
 * UserService
 */
public interface UserService {

    User addUser(User user);

    List<User> getAllUsers();

    User getUserById(Integer id);

    void deleteUserById(Integer id);

    UserDTO convertToDTO(User savedUser);
    List<UserDTO> convertToDTO(List<User> users);
    
}
