package hu.cs.se.adjava.raziaproject.dto;

import java.util.List;

public class UserDTO {

    private Integer _id;
    private String name;
    private String lname;
    private String phNumber;
    private String type;
    
    private Integer amantbookId;

    private List<Integer> buybooksIds;


    public Integer get_id() {
        return _id;
    }
  


    public List<Integer> getBuybooksIds() {
        return buybooksIds;
    }



    public void setBuybooksIds(List<Integer> buybooksIds) {
        this.buybooksIds = buybooksIds;
    }



    public Integer getAmantbookId() {
        return amantbookId;
    }


    public void setAmantbookId(Integer amantbookId) {
        this.amantbookId = amantbookId;
    }


    public void set_id(Integer _id) {
        this._id = _id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getLname() {
        return lname;
    }
    public void setLname(String lname) {
        this.lname = lname;
    }
    public String getPhNumber() {
        return phNumber;
    }
    public void setPhNumber(String phNumber) {
        this.phNumber = phNumber;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    
    
    
}
