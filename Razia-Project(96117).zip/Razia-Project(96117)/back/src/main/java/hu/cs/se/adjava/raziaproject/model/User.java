package hu.cs.se.adjava.raziaproject.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// this is table that is created for user

@Entity
@Table(name = "users")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})

public class User {

    private Integer _id;
    private String name;
    private String lname;
    private String phNumber;
    private String type;

    private Amanatbook amantbook;

    private Set<Amanatbook> amanats;
    
    
    private Set<books> buybooks;
    // getters and setter methods

    //JSON Ignore and all completing all Rellationship successfully
    @JsonBackReference
    // one user can read or buy many books in/from CofffeBook Library as a costumer .
   

    @OneToOne
    public Amanatbook getAmantbook() {
        return amantbook;
    }
    @OneToMany(mappedBy = "customer")
    public Set<books> getBuybooks() {
        return buybooks;
    }
    public void setBuybooks(Set<books> buybooks) {
        this.buybooks = buybooks;
    }
    public void setAmantbook(Amanatbook amantbook) {
        this.amantbook = amantbook;
    }

      // specify that how many book took user as Amanat
      @OneToMany(mappedBy = "give_Amanat_ToUser")
      public Set<Amanatbook> getAmanats() {
          return amanats;
      }
      public void setAmanats(Set<Amanatbook> amanats) {
          this.amanats = amanats;
      }
   

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getLname() {
        return lname;
    }
    public void setLname(String lname) {
        this.lname = lname;
    }
    public String getPhNumber() {
        return phNumber;
    }
    public void setPhNumber(String phNumber) {
        this.phNumber = phNumber;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public User(Integer _id, String name, String lname, String phNumber, String type) {
        this._id = _id;
        this.name = name;
        this.lname = lname;
        this.phNumber = phNumber;
        this.type = type;
    }

    public User() {

    }
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Integer get_id() {
        return _id;
    }
    public void set_id(Integer _id) {
        this._id = _id;
    }

  

    


    
}
