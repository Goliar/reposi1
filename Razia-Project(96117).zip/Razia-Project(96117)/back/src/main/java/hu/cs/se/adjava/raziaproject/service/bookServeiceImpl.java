package hu.cs.se.adjava.raziaproject.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.cs.se.adjava.raziaproject.Repository.bookRepository;
import hu.cs.se.adjava.raziaproject.dto.BookDTO;
import hu.cs.se.adjava.raziaproject.model.books;

@Service
public class bookServeiceImpl implements bookService {
    @Autowired
    private bookRepository bookRepository;
    @Autowired
     private ModelMapper modelMapper;
    @Override

    public books saveBook(books book) {
        
        return bookRepository.save(book);
    }
    @Override
    public List<books> getAll() {

        return bookRepository.findAll();
    }
    @Override
    public List<BookDTO> convertToDTO(List<books> books) {

        List<BookDTO> bookDTOList = new ArrayList<>();
        for(books book : books) {

            BookDTO bookDTO = modelMapper.map(book, BookDTO.class);
            bookDTOList.add(bookDTO);

        }
        return bookDTOList;
    }
    @Override
    public BookDTO convertToDTO(books book) {
        BookDTO bookDTO = modelMapper.map(book, BookDTO.class);
        
        return bookDTO;
    }
    @Override
    public books getBookById(Integer id) {

        return bookRepository.getOne(id);
    }
    @Override
    public books addBook(books book) {
        
        return bookRepository.save(book);
    }
    @Override
    public void deleteBookById(Integer id) {
        bookRepository.deleteById(id);
        
    }
}
