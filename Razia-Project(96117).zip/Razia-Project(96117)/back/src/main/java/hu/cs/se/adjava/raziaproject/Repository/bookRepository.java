package hu.cs.se.adjava.raziaproject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import hu.cs.se.adjava.raziaproject.model.books;

public interface bookRepository extends JpaRepository<books, Integer> {

}
