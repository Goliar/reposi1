package hu.cs.se.adjava.raziaproject.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import hu.cs.se.adjava.raziaproject.model.Amanatbook;

@Repository
public interface amantBookRepository extends JpaRepository<Amanatbook, Integer> {

    
}