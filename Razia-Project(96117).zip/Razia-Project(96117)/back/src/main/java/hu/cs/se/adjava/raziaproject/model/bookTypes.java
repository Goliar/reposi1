package hu.cs.se.adjava.raziaproject.model;

import java.io.Serializable;

import javax.persistence.Embeddable;


@Embeddable
public class bookTypes implements Serializable{

     private String type;

    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }

     
}
