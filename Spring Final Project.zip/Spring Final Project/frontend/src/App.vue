<template>
  <v-app>
    <Navbar/>
<v-container>
  <router-view></router-view>
    
    <!-- <gallary>
    <gallary-item v-for="(image, index) in images"
    src="image.src"
    caption="image.caption"
    v-bind:key="index"
    />

    </gallary> -->
  
</v-container>
  </v-app>
  
</template>



<script>

import Navbar from "@/components/Navbar.vue";

export default {

  //   data (){
  //   return {
  //     images: [
  //       {src: "/images/1.jpg", caption: "study it"},
  //       {src: "/images/2.jpg", caption: "study it"},
  //       {src: "/images/3.jpg", caption: "study it"},
  //       {src: "/images/4.jpg", caption: "study it"}
  //     ]
  //   }
  // },
   name: "App",

  components: {
    Navbar
  }
}
 

</script>
