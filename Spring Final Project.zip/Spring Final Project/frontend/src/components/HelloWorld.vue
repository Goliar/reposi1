<template  style="background-image: url('images/1.jpg')">
  <v-container>
    {{msg}}
  </v-container>
</template>

<script>
export default {
  name: "HelloWorld",
  props: ["msg"],

  data: () => ({
    hello: "Coffe Book"
  })
};
</script>
