<template>
  <div>
    <v-card >
      <v-app-bar color="#fffff" dark >
        <template v-slot:img="{ props }">
          <v-img v-bind="props" gradient=" rgba(0,201,.7), rgba(0,32,72,.7)"
          ></v-img>
        </template>

        <v-text-field style="width: 10px;" hide-details prepend-icon="mdi-magnify" single-line> -->
        </v-text-field>
        <v-toolbar-title >Cafe Book DataBase</v-toolbar-title>
        <v-spacer></v-spacer>


        <v-btn icon color= "error">
          <v-icon>mdi-heart</v-icon>
        </v-btn>

       <v-menu bottom left>
        <template v-slot:activator="{ on, attrs }">
          <v-btn icon color="yellow" v-bind="attrs" v-on="on">
            <v-icon>mdi-dots-vertical</v-icon>
          </v-btn>
        </template>

      </v-menu>

        <template v-slot:extension>
          
          <v-tabs align-with-title>
            <v-tab><router-link style="color: rgb(231, 222, 222)" to="/">Home</router-link></v-tab>

              <v-tab><router-link style="color: rgb(231, 222, 222)"  to="/user/add">Add User</router-link></v-tab>
              <v-tab><router-link style="color: rgb(231, 222, 222)"   to="/user/all">all users</router-link> </v-tab>

              <v-tab><router-link style="color: rgb(231, 222, 222)"  to="/books/add">Add Book</router-link></v-tab>
              <v-tab><router-link style="color: rgb(231, 222, 222)"   to="/books/all">all Books</router-link> </v-tab>
              
              <v-tab ><router-link style="color: rgb(231, 222, 222)"  to="/amanatbook/add">Add AmanatBook</router-link></v-tab>
              <v-tab><router-link style="color: rgb(231, 222, 222);"   to="/amanatbook/all">all AmanatBooks</router-link> </v-tab>
               <v-btn   style="color: rgb(231, 222, 222); align: right" @click="logout">Logout</v-btn>
         </v-tabs>
         <v-tabs v-if="!loggedIn">
                <v-tab><router-link style="color: rgb(231, 222, 222);" to="/user/register">Signup</router-link></v-tab>
                           
               <v-tab><router-link style="color: rgb(231, 222, 222);" to="/login">Login</router-link></v-tab>

         </v-tabs>


        </template>
      </v-app-bar>
      
        
      
    </v-card>


    
     
  </div>
</template>

<script>


export default {
  name: "App",


  data: () => ({
    //
  }),

  
  methods: {

    logout() {
      this.$store.dispatch("logout");
    }
  },
  computed: {
    loggedIn() {
      return this.$store.getters.loggedIn;
    }
  }
};
</script>

<style>

</style>