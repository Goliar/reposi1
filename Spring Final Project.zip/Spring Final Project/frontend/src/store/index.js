import Vue from "vue";
import Vuex from "vuex";
import adminUserService from "../api/adminUserService";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    text: "Hello",
    timeout: 6000,
    adminUser: null
  },
  mutations: {
    // SET_SNACKBAR: (state, payload) => {
    //   state.text = payload.text,
    //     state.timeout = payload.timeout
    // },

    SET_USER: (state, adminuserData) => {
      state.adminUser = adminuserData;
      localStorage.setItem("adminUser", JSON.stringify(adminuserData));
      adminUserService.addAuthorizationHeader(adminuserData.token);
    },
    CLEAR_USER: (() => {
      location.reload();
      localStorage.removeItem("adminUser");
    })
  },
  actions: {
    // updateSnackbar({ commit }, payload) {
    //   commit("SET_SNACKBAR", payload);
    // },
    async signup({ commit }, adminUser) {
      const response = await adminUserService.register(adminUser);

      commit("SET_USER", response.data);
    },
    async login({commit}, adminUser) {
      const response = await adminUserService.login(adminUser);
      commit("SET_USER", response.data);
    },

    logout({ commit }) {
      commit("CLEAR_USER");
    }
  },

  getters: {
    loggedIn(state) {
      return !!state.adminuser;
    }
  },

  modules: {}
});
