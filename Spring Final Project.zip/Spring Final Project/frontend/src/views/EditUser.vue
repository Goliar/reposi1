<template>
 <div>
     <UserForm :userId = "userId"/>
     
 </div>
</template>

<script>
import UserForm from "../components/UserForm"
export default {
components:{
UserForm:UserForm
},
data() {
    return{
        userId:this.$route.params.id
    }
}
}
</script>

<style>

</style>