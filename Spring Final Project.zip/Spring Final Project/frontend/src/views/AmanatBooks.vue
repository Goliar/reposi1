<template>
  <div>
    <v-simple-table>
       <template v-slot:default>
         <thead>
           <tr>
             <th class= "text-left"> Name</th>
              <th class= "text-left"> Time</th>
              <th class= "text-left">Cost</th>
               <th class= "text-left">Action</th>
           </tr>
         </thead>
         <tbody>
          <tr v-for= "amanatbook in amanatbooks" :key= "amanatbook._id">
            <td>{{amanatbook.name}}</td>
            <td>{{amanatbook.time}}</td>
            <td>{{amanatbook.cost}}</td>

            <td>
              <v-btn :to= "`/amanatbook/${amanatbook._id}/edit`" small color= "warning" class= "mr-2" >Edit</v-btn>
              <v-btn small color= "error" @click= "deleteAmanatBook(amanatbook._id)" >Delete</v-btn>

            </td>

          </tr>
         </tbody>
       </template>
    </v-simple-table>
  </div>
</template>

<script>
import AmanatBookService from '../api/AmanatBookService'
export default {
  data(){
    return{
      amanatbooks:[]
     
    }
  },
   methods:{
 async deleteAmanatBook(amanatbookId) {
   const conf= confirm("Do you want to delete the amanatbook?");
   if(conf){
   const response= await AmanatBookService.deleteAmanatbookById(amanatbookId);
      console.log(response.data);
      this.amanatbooks= this.amanatbooks.filter(amanatbook =>{
        return amanatbook._id!== AmanatBookService;
        
})
   }
 }
  },
  async mounted() {

   const response= await AmanatBookService.getAll();
      this.amanatbooks= response.data;
  }

}
</script>

<style>
th,
td {
  border: 1px solid grey;
}
</style>