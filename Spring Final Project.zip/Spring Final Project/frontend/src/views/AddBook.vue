<template>
  <div class="about">
    <v-row>
     
      <v-col cols="12" class="mx-auto dark--text">
         <h1>Add Book</h1>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="name" label="name" outlined></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="quantity" type="Number" label="quantity" outlined></v-text-field>
      </v-col>
    </v-row>

     <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-select v-model="category" 
            :items="items"
            label="category "
            outlined

          >

          </v-select>
        </v-col>
      </v-row>


      <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-btn v-if="booksId" color="info" @click="updateBook">Update</v-btn>

          <v-btn color="info" @click="addBook">Save</v-btn>
        </v-col>
      </v-row>
  </div>
</template>

<script>
import BookService from "../api/BookService"
export default {
   props: ["booksId"],
  data(){
    return {
      name:null,
      quantity:null,
      category:null,
      items:["letrature","history", "mathmatic","Programming", "art", "stories", "English"],
      required: value => !!value || "This field is required"

    };
  },

  methods: {
   async addBook() {
    //  if(this.$refs.form.validate()){
      const book = {
          name: this.name,
          quantity : this.quantity,
          category: this.category
        };

          
      const saveBook = await BookService.saveBook(book);
        console.log(saveBook);
        this.resetForm();

        this.$router.push("/books/all");
      // }else{
      //   console.log("Form is not valid");
      // }
   


  },

  resetForm(){
  // this.$refs.form.reset();
  this.name =null
  this.quantity =null
  this.category =null

}
}

}
</script>
