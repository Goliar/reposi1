<template>
  <div class="about">
    <v-row>
     
      <v-col cols="12" class="mx-auto dark--text">
         <h1>Add AmanatBook</h1>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="name" label=" name" outlined></v-text-field>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field v-model="time" label="time " outlined></v-text-field>
      </v-col>
    </v-row>

     

      <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-text-field v-model="cost" label="cost" outlined></v-text-field>
        </v-col>
      </v-row>

      <v-row>
        <v-col cols="12" sm="6" class="mx-auto">
          <v-btn v-if="amanatbookId" color="info" @click="updateAmanatbook">Update</v-btn>

          <v-btn color="info" @click="saveAmanatbook">Save</v-btn>
        </v-col>
      </v-row>
  </div>
</template>

<script>
import AmanatBookService from "../api/AmanatBookService"
export default {
   props: ["amanatbookId"],
  data(){
    return {
      name:null,
      time:null,
      cost:null,
      required: value => !!value || "This field is required"

    };
  },

  methods: {
   async saveAmanatbook() {
    //  if(this.$refs.form.validate()){
      const amanatbook = {
          name: this.name,
          time : this.time,
          cost : this.cost,
        };

          
      const saveAmanatbook = await AmanatBookService.saveAmanatbook(amanatbook);
        console.log(saveAmanatbook);
        this.resetForm();

        this.$router.push("/amanatbook/all");
      // }else{
      //   console.log("Form is not valid");
      // }
   


  },

  resetForm(){
  // this.$refs.form.reset();
  this.name =null
  this.time =null
  this.cost =null

}
}

}
</script>
