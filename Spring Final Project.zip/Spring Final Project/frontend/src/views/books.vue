<template>
  <div>
    <v-simple-table>
       <template v-slot:default>
         <thead>
           <tr>
             <th class= "text-left">Name</th>
              <th class= "text-left">Quantity</th>
              <th class= "text-left">category</th>
               <th class= "text-left">Action</th>
           </tr>
         </thead>
         <tbody>
          <tr v-for= "book in books" :key= "book._id">
            <td>{{book.name}}</td>
            <td>{{book.quantity}}</td>
             <td>{{book.category}}</td>

            <td>
              <v-btn :to= "`/book/${book._id}/edit`" small color= "warning" class= "mr-2" >Edit</v-btn>
              <v-btn small color= "error" @click= "deleteBook(book._id)" >Delete</v-btn>

            </td>

          </tr>
         </tbody>
       </template>
    </v-simple-table>
  </div>
</template>

<script>
import BookService from "../api/BookService"
export default {
  data(){
    return{
      books:[]
     
    }
  },
   methods:{
 async deleteBook(bookId) {
   const conf= confirm("Do you want to delete the book?");
   if(conf){
   const response= await BookService.deleteBookById(bookId);
      console.log(response.data);
      this.books= this.books.filter(book =>{
        return book._id!== BookService;
        
})
   }
 }
  },
  async mounted() {

   const response= await BookService.getAll();
      this.books= response.data;
  }

}
</script>

<style>
th,
td {
  border: 1px solid grey;
}
</style>