<template>
  <div class="home">
    <HelloWorld msg="Welcome to Coffe Book " />
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from "@/components/HelloWorld.vue";

export default {

      data (){
    return {
      // images: [
      //   {src: "/images/1.jpg", caption: "study it"},
      //   {src: "/images/2.jpg", caption: "study it"},
      //   {src: "/images/3.jpg", caption: "study it"},
      //   {src: "/images/4.jpg", caption: "study it"}
      // ]
    }
  },
  name: "Home",
  components: {
    HelloWorld
  }
};
</script>
<style>
  #Home
  {
    width: 60%;
  }

</style>

