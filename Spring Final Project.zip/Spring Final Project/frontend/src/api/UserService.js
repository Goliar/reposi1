import axiosClient from "./axiosClient"

export default {
    addUser(user){
        return axiosClient.post("/user/add", user);

    },
    getAllUsers(){
        return axiosClient.get("/user/all")
    },

    deleteUserById(userId) {
        return axiosClient.delete(`/user/${userId}/delete`);
      },
    
      getUserById(userId) {
        return axiosClient.get(`/user/${userId}`);
      },
    
      updateUser(user) {
        return axiosClient.put("/user/update", user);
      }
}