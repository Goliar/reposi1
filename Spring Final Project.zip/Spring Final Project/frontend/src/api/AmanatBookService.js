import axiosClient from "./axiosClient"

export default {
    saveAmanatbook(amanatbook){
        return axiosClient.post("/amanatbook/add", amanatbook);

    },
    getAll(){
        return axiosClient.get("/amanatbook/all")
    },

    deleteAmanatbookById(amanatbookId) {
        return axiosClient.delete(`/amanatbook/${amanatbookId}/delete`);
      },
    
      getAmanatById(amanatbookId) {
        return axiosClient.get(`/amanatbook/${amanatbookId}`);
      },
    
      updateUser(amanatbook) {
        return axiosClient.put("/amanatbook/update", amanatbook);
      }
}