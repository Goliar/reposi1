import axiosClient from "./axiosClient"

export default {
    saveBook(book){
        return axiosClient.post("/books/add", book);

    },
    getAll(){
        return axiosClient.get("/books/all")
    },

    deleteBookById(bookId) {
        return axiosClient.delete(`/books/${bookId}/delete`);
      },
    
      getBookById(bookId) {
        return axiosClient.get(`/books/${bookId}`);
      },
    
      addBook(book) {
        return axiosClient.put("/books/update", book);
      }
}