package hu.cs.se.adjava.raziaproject.service;

import java.util.List;

import hu.cs.se.adjava.raziaproject.dto.BookDTO;
import hu.cs.se.adjava.raziaproject.model.books;

public interface bookService {

    books saveBook(books book);

    List<books> getAll();


    books addBook(books book);

    void deleteBookById(Integer id);
    
    books getBookById(Integer id);
    
    List<BookDTO> convertToDTO(List<books> books);
    BookDTO convertToDTO(books book);


}
