package hu.cs.se.adjava.raziaproject.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import hu.cs.se.adjava.raziaproject.Repository.UserRepository;
import hu.cs.se.adjava.raziaproject.dto.UserDTO;
import hu.cs.se.adjava.raziaproject.model.User;
@Service
public class UserServiceimpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired 
    private ModelMapper modelMapper;

    @Override
    public User addUser(User user) {
        
        return userRepository.save(user);
    }


    @Override
    public List<User> getAllUsers() {
        
        return userRepository.findAll();
    }


    @Override
    public User getUserById(Integer id) {
        
        return userRepository.getOne(id);
    }


    @Override
    public void deleteUserById(Integer id) {
       
        userRepository.deleteById(id);   }


    @Override
    public List<UserDTO> convertToDTO(List<User> users) {
        

        List<UserDTO> userDTOList = new ArrayList<>();
        for(User user : users) {

            UserDTO userDTO = modelMapper.map(user, UserDTO.class); 
            // userDTO.setBuybooks_Ids(user.getBuybooks().stream().map(books -> books.getId()).collect(Collectors.toList()));
            userDTOList.add(userDTO);
            

        }
        return userDTOList;
    }


    @Override
    public UserDTO convertToDTO(User user) {
       
        UserDTO userDTO = modelMapper.map(user, UserDTO.class); 

        return userDTO;
    }


  
    
}
