package hu.cs.se.adjava.raziaproject.dto;

public class AmanatDTO {
    
    private Integer _id;
    private String name;
    private String time;
    private Integer cost;

    private Integer give_Amanat_ToUser_Id;

    
    public Integer get_id() {
        return _id;
    }


    public void set_id(Integer _id) {
        this._id = _id;
    }


    public Integer getGive_Amanat_ToUser_Id() {
        return give_Amanat_ToUser_Id;
    }


    public void setGive_Amanat_ToUser_Id(Integer give_Amanat_ToUser_Id) {
        this.give_Amanat_ToUser_Id = give_Amanat_ToUser_Id;
    }


    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public Integer getCost() {
        return cost;
    }
    public void setCost(Integer cost) {
        this.cost = cost;
    }




    
}
