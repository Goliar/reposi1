package hu.cs.se.adjava.raziaproject.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import hu.cs.se.adjava.raziaproject.Repository.AdminRepository;
import hu.cs.se.adjava.raziaproject.model.Admin;

@Service
public class UserDetailsServiceImpl implements UserDetailsService{

    @Autowired
    private AdminRepository adminRepository;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
       Admin admin = adminRepository.findByUsername(username);
        return new org.springframework.security.core.userdetails.User(admin.getUsername(),
        admin.getPassword(), new ArrayList<>());
    }
    
}
