package hu.cs.se.adjava.raziaproject.dto;

public class BookDTO {

    private Integer _id;
    private String category;
    private String name;
    private Integer quantity;
 
    private Integer customer_Id;

    
    
    public Integer getCustomer_Id() {
        return customer_Id;
    }


    public String getCategory() {
        return category;
    }


    public void setCategory(String category) {
        this.category = category;
    }


    public void setCustomer_Id(Integer customer_Id) {
        this.customer_Id = customer_Id;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }


    public Integer get_id() {
        return _id;
    }


    public void set_id(Integer _id) {
        this._id = _id;
    }

    
    
}
