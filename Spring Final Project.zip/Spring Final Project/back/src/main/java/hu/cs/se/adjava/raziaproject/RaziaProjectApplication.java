package hu.cs.se.adjava.raziaproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import hu.cs.se.adjava.raziaproject.Repository.AdminRepository;
import hu.cs.se.adjava.raziaproject.model.Admin;

@SpringBootApplication
public class RaziaProjectApplication implements CommandLineRunner {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private AdminRepository adminRepository;
	public static void main(String[] args) {
		SpringApplication.run(RaziaProjectApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		Admin initialAdmin = adminRepository.findByUsername("admin");

		if(initialAdmin == null) {
			Admin admin1 = new Admin("Razia","Mohammadi", "admin", "raziamohammadi@gmail.com", bCryptPasswordEncoder.encode("admin"));
			adminRepository.save(admin1);
		}
		
		


	}

}
