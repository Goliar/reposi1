package hu.cs.se.adjava.raziaproject.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class Amanatbook {

    private Integer _id;
    private String name;
    private String time;
    private Integer cost;

    private User user;

   
    private User give_Amanat_ToUser;
    
    // user has a one to one realation with amanatBook and amanat book sends forgian key to user
    @OneToOne(mappedBy = "amantbook")
    public User getUser() {
        return user;
    }
    public void setUser(User user) {
        this.user = user;
    }

    //coffeBook gives ane user many book as loan or amanat 
    @ManyToOne
    public User getGive_Amanat_ToUser() {
        return give_Amanat_ToUser;
    }
    public void setGive_Amanat_ToUser(User give_Amanat_ToUser) {
        this.give_Amanat_ToUser = give_Amanat_ToUser;
    }


    @Id
    @GeneratedValue
    public Integer get_id() {
        return _id;
    }
    public void set_id(Integer _id) {
        this._id = _id;
    }
    
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public Integer getCost() {
        return cost;
    }
    public void setCost(Integer cost) {
        this.cost = cost;
    }
    

   
}
