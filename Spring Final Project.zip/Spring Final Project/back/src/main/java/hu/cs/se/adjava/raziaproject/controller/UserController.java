package hu.cs.se.adjava.raziaproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.se.adjava.raziaproject.dto.UserDTO;
import hu.cs.se.adjava.raziaproject.model.User;
import hu.cs.se.adjava.raziaproject.service.UserService;
import hu.cs.se.adjava.raziaproject.service.amanatBookService;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")

// in this page all CRUD operation done add, delete, update, edit 

public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private amanatBookService amanatbookService;

    @GetMapping("/user/all")
    public ResponseEntity<List<UserDTO>> getUsers() { 
          
        List<User> users = userService.getAllUsers();

        List<UserDTO> userDTOList = userService.convertToDTO(users);

        return new ResponseEntity<>(userDTOList, HttpStatus.OK);
    }
    
    @PostMapping("/user/add")
    public ResponseEntity<UserDTO> addUser(@RequestBody User user){

    //  user.setAmantbook(amanatbookService.getAmanatById(1));
        
       User savedUser = userService.addUser(user);

       UserDTO userDTO = userService.convertToDTO(savedUser);
        return new ResponseEntity<>(userDTO, HttpStatus.CREATED);
    }
    @GetMapping("/user/{id}")
    public ResponseEntity<User> getUser(@PathVariable("id") Integer id){

        User user = userService.getUserById(id);


        return new ResponseEntity<>(user, HttpStatus.OK);
    } 

    @PutMapping("/user/update")
    public ResponseEntity<User> updateUser(@RequestBody User user){

        User SavedUser = userService.addUser(user);
         return new ResponseEntity<>(SavedUser, HttpStatus.OK);

        }

        @DeleteMapping("/user/{id}/delete")
        public ResponseEntity<String> deleteUser(@PathVariable("id") Integer id){

            userService.deleteUserById(id);

            return new ResponseEntity<>("User " + id  + "deleted", HttpStatus.OK);
            
        }
      


}
