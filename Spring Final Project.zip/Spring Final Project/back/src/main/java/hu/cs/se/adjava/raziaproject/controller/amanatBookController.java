package hu.cs.se.adjava.raziaproject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.se.adjava.raziaproject.dto.AmanatDTO;
import hu.cs.se.adjava.raziaproject.model.Amanatbook;
import hu.cs.se.adjava.raziaproject.service.UserService;
import hu.cs.se.adjava.raziaproject.service.amanatBookService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class amanatBookController {

    @Autowired
    private amanatBookService amanatService;

    @Autowired
    private UserService userService;
  
    @GetMapping("/amanatbook/all")
    public ResponseEntity<List<AmanatDTO>> getAllAmanats() {

        List<Amanatbook> amanats = amanatService.getAll();

        List<AmanatDTO> amanatDTOList = amanatService.convertToDTO(amanats);
 
        return new ResponseEntity<>(amanatDTOList, HttpStatus.OK);
    }

    @PostMapping(value = "/amanatbook/add")
    public ResponseEntity<AmanatDTO> addAmantbook(@RequestBody Amanatbook amanatbook) {

        // amanatbook.setGive_Amanat_ToUser(userService.getUserById(2));
        Amanatbook savedAmanatbook = amanatService.saveAmanatbook(amanatbook);

        AmanatDTO amanatDTO = amanatService.convertToDTO(savedAmanatbook);
        return new ResponseEntity<>(amanatDTO, HttpStatus.CREATED);
    }

    @GetMapping("/amanatbook/{id}")
    public ResponseEntity<Amanatbook> getUser(@PathVariable("id") Integer id){

        Amanatbook amanatbook = amanatService.getAmanatById(id);

        return new ResponseEntity<>(amanatbook, HttpStatus.OK);
    } 

    
    @PutMapping("/amanatbook/update")
    public ResponseEntity<Amanatbook> updateUser(@RequestBody Amanatbook amanatbook){

        Amanatbook savedAmanatbook = amanatService.saveAmanatbook(amanatbook);
         return new ResponseEntity<>(savedAmanatbook, HttpStatus.OK);

        }

        
        @DeleteMapping("/amanatbook/{id}/delete")
        public ResponseEntity<String> deleteAmanatbook(@PathVariable("id") Integer id){

            amanatService.deleteAmanatbookById(id);

            return new ResponseEntity<>("AmanatBook " + id  + "deleted", HttpStatus.OK);
            
        }

    
}
