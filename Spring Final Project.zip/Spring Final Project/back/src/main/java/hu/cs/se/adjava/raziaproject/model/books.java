package hu.cs.se.adjava.raziaproject.model;

import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "books")
@JsonIgnoreProperties(value = {"hibernateLazyInitializer", "handler"})
public class books {

   private Integer _id;
   private String category;
   private String name;
   private Integer quantity;

   private User customer;

   private Set<bookTypes> booktypes;

   //many books can be study by one customer/user in library
   @ManyToOne
   public User getCustomer() {
    return customer;
    }


    @ElementCollection
    @CollectionTable(name = "types",
    joinColumns = @JoinColumn(name ="b_id"))
     public Set<bookTypes> getBooktypes() {
     return booktypes;
        }
     public void setBooktypes(Set<bookTypes> booktypes) {
            this.booktypes = booktypes;
        }

    public void setCustomer(User customer) {
        this.customer = customer;
    }

  

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public Integer getQuantity() {
        return quantity;
    }
    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    @Id
    @GeneratedValue 
    public Integer get_id() {
        return _id;
    }

    public void set_id(Integer _id) {
        this._id = _id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
   

    
        
    }
