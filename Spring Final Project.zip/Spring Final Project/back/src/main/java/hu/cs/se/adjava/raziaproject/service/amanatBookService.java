package hu.cs.se.adjava.raziaproject.service;

import java.util.List;

import hu.cs.se.adjava.raziaproject.dto.AmanatDTO;
import hu.cs.se.adjava.raziaproject.model.Amanatbook;

public interface amanatBookService {

    Amanatbook saveAmanatbook(Amanatbook amanatbook);

    List<Amanatbook> getAll();

    Amanatbook getAmanatById(Integer id);

    void deleteAmanatbookById(Integer id);


    List<AmanatDTO> convertToDTO(List<Amanatbook> amanats);
    AmanatDTO convertToDTO(Amanatbook amanatbook);

} 