package hu.cs.se.adjava.raziaproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import hu.cs.se.adjava.raziaproject.Repository.AdminRepository;
import hu.cs.se.adjava.raziaproject.model.Admin;
import hu.cs.se.adjava.raziaproject.model.JwtRequest;
import hu.cs.se.adjava.raziaproject.model.JwtResponse;
import hu.cs.se.adjava.raziaproject.util.JwtUtility;

@RestController
public class SecurityController {
    @Autowired
    private JwtUtility jwtUtility;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    @Qualifier("userDetailsServiceImpl")
    private UserDetailsService userDetailsService;

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;


    @PostMapping("/api/authenticate")
    public JwtResponse authenticate(@RequestBody JwtRequest jwtRequest) throws Exception{
       try {
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getUsername(),
        jwtRequest.getPassword()));
       } catch (BadCredentialsException e) {
           throw new Exception("Bad Credientials");
       }

       UserDetails userDetails = userDetailsService.loadUserByUsername(jwtRequest.getUsername());
       String jwtToken = jwtUtility.generateToken(userDetails);

       Admin admin = adminRepository.findByUsername(jwtRequest.getUsername()); 

        return new JwtResponse(admin.getFirstName()+" "+ admin.getLastName(),
        admin.getUsername(), jwtToken);
    }

    @PostMapping("/api/register")
    public JwtResponse register(@RequestBody  Admin admin) {

        admin.setPassword(bCryptPasswordEncoder.encode(admin.getPassword()));
        adminRepository.save(admin);

        UserDetails userDetails = userDetailsService.loadUserByUsername(admin.getUsername());

        String jwtToken = jwtUtility.generateToken(userDetails);

        return new JwtResponse(admin.getFirstName() + " " + admin.getLastName(),
        admin.getUsername(), jwtToken);

    }

    
}
